<!-- Nama : Fahrel Gibran Alghany -->
<!-- NIM : 24060120130106 -->

<h2>Show Server Time Now</h2>
<?php
echo date('H:i:s');
?>